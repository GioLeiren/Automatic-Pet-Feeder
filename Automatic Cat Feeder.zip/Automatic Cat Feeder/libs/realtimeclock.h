#ifndef __REALTIMECLOCK_H_
#define __REALTIMECLOCK_H_

void configureRTC(void);

#endif
