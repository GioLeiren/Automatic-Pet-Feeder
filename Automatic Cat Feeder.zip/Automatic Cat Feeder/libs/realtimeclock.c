#include <msp430.h>
#include <stdint.h>
#include "realtimeclock.h"

void configureRTC(void)
{
    RTCCTL01 = RTCAIE | RTCMODE | RTCSSEL__RT1PS;

    RTCSEC = 0;
    RTCMIN = 29;
    RTCHOUR = 10;
    RTCDOW = 5;
    RTCAMIN = RTCAE | 30;
    RTCAHOUR = RTCAE | 10;
    RTCADOW = RTCAE | 5;

    RTCPS0CTL = RT0PSDIV_6;
    RTCPS1CTL = RT1SSEL_2 | RT1PSDIV_7;
}

