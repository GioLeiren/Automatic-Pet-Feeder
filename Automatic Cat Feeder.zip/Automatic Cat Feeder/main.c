#include <msp430.h> 
#include <stdint.h>
#include <stdlib.h>
#include "libs/servomotor.h"
#include "libs/realtimeclock.h"
#include "libs/uart.h"

char uart_input[6];
char uart_input_char;
unsigned int uart_input_index = 0;

void setTime(char vector[6]);
void setAlarm(char vector[6]);

void main(void)
{
    WDTCTL = WDTPW | WDTHOLD;	// stop watchdog timer

    uartInit();
    Servo_Config();
    configureRTC();

    P1DIR |= BIT0;
    P1OUT &= ~BIT0;

    P4DIR |= BIT7;
    P4OUT &= ~BIT7;

    __enable_interrupt();

    while(1){
        if (uart_input_index == 6){
            if (uart_input[0] == 'H' || uart_input[0] == 'h'){
                setTime(uart_input);
                P4OUT ^= BIT7;
                __delay_cycles(1000000);
            }
            else if (uart_input[0] == 'A' || uart_input[0] == 'a'){
                setAlarm(uart_input);
                P4OUT ^= BIT7;
                __delay_cycles(1000000);
            }
            uart_input_index = 0;
        }
        else{
            if (uart_input_index > 6){
                uart_input_index = 0;
            }
            else{
                if (uart_input_char == 'r'){
                    uart_input_index = 0;
                }
            }
        }
    }
}

void setTime(char vector[6]){
    char day[2];
    char hour[3];
    char minute[3];
    day[0] = vector[1];
    day[1] = '\0';
    hour[0] = vector[2];
    hour[1] = vector[3];
    hour[2] = '\0';
    minute[0] = vector[4];
    minute[1] = vector[5];
    minute[2] = '\0';
    int d = atoi(day);
    int h = atoi(hour);
    int m = atoi(minute);
    RTCDOW = d;
    RTCHOUR = h;
    RTCMIN = m;
}

void setAlarm(char vector[6]){
    RTCADOW = 0;
    RTCAHOUR = 0;
    RTCAMIN = 0;
    char day[2];
    char hour[3];
    char minute[3];
    day[0] = vector[1];
    day[1] = '\0';
    hour[0] = vector[2];
    hour[1] = vector[3];
    hour[2] = '\0';
    minute[0] = vector[4];
    minute[1] = vector[5];
    minute[2] = '\0';
    int d = atoi(day);
    int h = atoi(hour);
    int m = atoi(minute);
    RTCADOW = RTCAE | d;
    RTCAHOUR = RTCAE | h;
    RTCAMIN = RTCAE | m;
}

// RTC interrup��o
#pragma vector = RTC_VECTOR
__interrupt void RTC_ISR()
{
    switch (RTCIV) {
    case RTCIV_RTCAIFG:
        P4OUT ^= BIT7;
        Servo_SetPosition(180);
        __delay_cycles(3000000);

        Servo_SetPosition(0);
        __delay_cycles(1000000);
        break;
    default:
        break;
    }
}

// UART interrup��o
#pragma vector = USCI_A1_VECTOR
__interrupt void USCI_A1_ISR(void)
{
    switch(UCA1IV){
    case 0:
        break;
    case 2:
        uart_input[uart_input_index++] = UCA1RXBUF;
        uart_input_char = UCA1RXBUF;
        P1OUT ^= BIT0;
        break;
    default:
        break;
    }
}
